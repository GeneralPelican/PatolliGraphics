package implementaciones;

import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;

public class Tablero extends Canvas {

    private int ancho, alto;
    private int numCasillasAspa;
    private AffineTransform tx;

    public Tablero(int ancho, int alto, int numCasillas) {
        this.ancho = ancho;
        this.alto = alto;
        this.numCasillasAspa = numCasillas;
        tx = new AffineTransform();
        this.setBounds(0, 0, ancho, alto);
        this.setBackground(Color.black);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        Graphics2D g2d = (Graphics2D) g;
        dibujarTablero(g2d);
        
        g2d.setColor(Color.red);
        tx.scale(1.5, 1.5);
        g2d.setTransform(tx);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawString("Turno: Jugador #1", 10, 15);
        g2d.drawString("Apuesta: $200", 10, 30);
        g2d.drawString("Dado: 6", ancho/2+50, 15);
        
    }

    public void dibujarTablero(Graphics2D g2d) {
        int cas = numCasillasAspa-2;
        int w = 20, h = 20, gap = 5;

        //dibujar aspas horizontales en el centro
        g2d.setColor(Color.blue);
        dibujarAspaHorizontal(ancho / 2 - (w * (cas / 2) + (cas / 2 * gap) + w + gap), alto / 2 + gap, w, h, cas, gap, 1, g2d);
        dibujarAspaHorizontal(ancho / 2 + w + gap, alto / 2 + gap, w, h, cas, gap, -1, g2d);
        
        //dibujar el centro
        int xi=ancho/2-w-gap,yi = alto/2-h;
        for (int i = 0; i < 4; i++) {
            g2d.fillRect(xi, yi, w, h);
            xi= i == 4/2-1? ancho/2-w-gap:xi+gap+w;
            yi= i == 4/2-1? yi+h+gap:yi;
        }
        
        //dibujar aspas verticales en el centro
        dibujarAspaVertical(ancho / 2, alto / 2 + h + (gap * 2), w, h, cas, gap, -1, g2d);
        dibujarAspaVertical(ancho / 2, alto / 2 - (h * cas / 2) - h*2 - (gap * 2)+gap, w, h, cas, gap, 1,g2d);
    }

    public void dibujarAspaHorizontal(int xi, int yi, int ancho, int alto, int cuantos, int gap, int dir, Graphics2D g2d) {
        Graphics2D g2 = (Graphics2D) g2d.create();
        int xAux = xi, yAux = yi;
        g2.setStroke(new BasicStroke(3));
        if (dir == -1) {
            pintarEsquina(xi + (cuantos/2) * ancho + (cuantos/2 * gap)+gap, yi - alto, ancho * 2, alto * 2, 0, 90,-gap,g2);
            pintarEsquina(xi + (cuantos/2) * ancho + (cuantos/2 * gap)+gap, yi-alto+gap, ancho*2, alto*2, 270,90,-gap, g2);
            
            for (int i = 0; i < cuantos; i++) {
                if(i==cuantos-1 ||i==cuantos/2-1){
                    g2.fillRect(xi, yi, ancho*2, alto);
                }else{ g2.fillRect(xi, yi, ancho, alto);}
                xi = i == cuantos / 2 - 1 ? xAux : xi + ancho + gap;
                yi = i == cuantos / 2 - 1 ? yi - alto - gap : yi;
            }
            pintarTriangulo(xi-gap,yi+alto+gap,ancho/2,alto,1,g2d);
            pintarTriangulo(xi-gap,yi+alto,ancho/2,alto,-1,g2d);
        } else {
            pintarEsquina(xi - (ancho*2), yi - alto, ancho * 2, alto * 2, 90, 90, -gap,g2);
            pintarEsquina(xi - (ancho*2), yi - alto+gap, ancho * 2, alto * 2, 180, 90,-gap,g2);
            
            for (int i = 0; i < cuantos; i++) {
                if(i==0 ||i==cuantos/2){
                   g2.fillRect(xi-ancho, yi, ancho*2, alto);
                }else{ g2.fillRect(xi, yi, ancho, alto);}
                xi = i == cuantos / 2 - 1 ? xAux : xi + ancho + gap;
                yi = i == cuantos / 2 - 1 ? yi - alto - gap : yi;
            }
            pintarTriangulo(xAux+gap/2,yAux,ancho/2,alto,1,g2d);
            pintarTriangulo(xAux+gap/2,yAux-gap,ancho/2,alto,-1,g2d);
        }
    }

    public void dibujarAspaVertical(int xi, int yi, int ancho, int alto, int cuantos, int gap, int dir,Graphics2D g2d) {
        Graphics2D g2 = (Graphics2D) g2d.create();
        int yAux = yi, xAux=xi;
        g2.setStroke(new BasicStroke(3));
        if(dir == 1){
            pintarEsquina(xi-ancho,yi-(alto*2), ancho*2, alto*2, 90,90, -gap,g2);
            pintarEsquina(xi-ancho+gap,yi-(alto*2), ancho*2, alto*2, 0,90, -gap,g2);
            
            for (int i = 0; i < cuantos; i++) {
                if(i==0 || i==cuantos/2){
                    g2.fillRect(xi, yi-alto, ancho, alto*2);
                }else{ g2.fillRect(xi, yi, ancho, alto); }
                yi = i == cuantos / 2 - 1 ? yAux : yi + alto + gap;
                xi = i == cuantos / 2 - 1 ? xi - ancho - gap : xi;
            }
            pintarTriangulo(xAux,yAux,ancho,alto/2,2,g2d);
            pintarTriangulo(xAux-gap,yAux,ancho,alto/2,-2,g2d);
        }else{
            pintarEsquina(xi-ancho-gap*2,yi+(cuantos/2)*alto+(gap*(cuantos/2))-gap, ancho*2, alto*2, 180,90, gap,g2);
            pintarEsquina(xi-ancho-gap,yi+(cuantos/2)*alto+(gap*(cuantos/2))-gap, ancho*2, alto*2, 270,90, gap,g2);
            
            for (int i = 0; i < cuantos; i++) {
                if(i==cuantos-1 || i==cuantos/2-1){
                    g2.fillRect(xi, yi, ancho, alto*2);
                }else{ g2.fillRect(xi, yi, ancho, alto); }
                yi = i == cuantos / 2 - 1 ? yAux : yi + alto + gap;
                xi = i == cuantos / 2 - 1 ? xi - ancho - gap : xi;
            }
            pintarTriangulo(xi+ancho+gap,yi,ancho,alto/2,2,g2d);
            pintarTriangulo(xi+ancho,yi,ancho,alto/2,-2,g2d);
        }
    }

    private void pintarEsquina(int xi, int yi, int ancho, int alto, int angInicio, int angFin,int gap,Graphics2D g2d){
        Graphics2D g2 = (Graphics2D) g2d.create();
        g2.setStroke(new BasicStroke(2));
        Arc2D.Double esquina = new Arc2D.Double(xi+gap, yi+gap, ancho, alto, angInicio, angFin, Arc2D.PIE);
        g2.fill(esquina);
    }
    
    //dirección; 1 arriba, -1 abajo, 2 izquierda, -2 derecha
    private void pintarTriangulo(int xi, int yi, int ancho, int alto, int dir,Graphics2D g2d){
        Graphics2D g2 = (Graphics2D) g2d.create();
        g2.setColor(Color.red);
        g2.setStroke(new BasicStroke(2));
        int[] xPuntos = {}, yPuntos = {};
        
        if(dir == 1){
            xPuntos = new int[]{xi,xi+ancho,xi-ancho};
            yPuntos = new int[]{yi,yi+alto,yi+alto};
        }else if(dir == -1){
            xPuntos = new int[]{xi,xi+ancho,xi-ancho};
            yPuntos = new int[]{yi,yi-alto,yi-alto};
        }else if(dir == 2){
            xPuntos = new int[]{xi,xi+ancho,xi+ancho};
            yPuntos = new int[]{yi,yi-alto,yi+alto};
        }else{
            xPuntos = new int[]{xi,xi-ancho,xi-ancho};
            yPuntos = new int[]{yi,yi-alto,yi+alto};
        }
        Polygon triangulo = new Polygon(xPuntos,yPuntos,3);
        g2.fill(triangulo);
    }
    
}
